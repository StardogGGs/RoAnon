const forceReactUpdate = (element, value) => {
    
    const nativeInputValueSetter = Object.getOwnPropertyDescriptor(window.HTMLInputElement.prototype, "value").set;
    
    
    nativeInputValueSetter.call(element, value);

    
    element.dispatchEvent(new Event('input', { bubbles: true }));
};

const Fill = () => {
    
    const selectors = [
        'input[name="signupUsername"]',
        '#signup-username',
        'input[placeholder*="Username"]',
        '.username-input'
    ];

    let userInput = null;
    for (const selector of selectors) {
        userInput = document.querySelector(selector);
        if (userInput) break;
    }

    if (userInput && !userInput.dataset.anonymized) {
        
        if (userInput.offsetWidth > 0 || userInput.offsetHeight > 0) {
            
            const anonName = "anon" + Math.floor(Math.random() * 1e9);
            
            
            forceReactUpdate(userInput, anonName);
            
            
            userInput.dataset.anonymized = "true";
            
            console.log("New Account Username set to: " + anonName);
        }
    }
};

const scanner = setInterval(Fill, 500);

document.addEventListener('click', Fill);

console.log("Scanner Active");